package com.abhishek.hubspot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HubspotRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
