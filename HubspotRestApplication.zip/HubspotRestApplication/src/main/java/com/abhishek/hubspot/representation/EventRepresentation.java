package com.abhishek.hubspot.representation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/**
 * Event representation as received from GET REST endpoint.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventRepresentation {

    @NonNull
    private String url;

    @NonNull
    private String visitorId;

    @NonNull
    private Long timestamp;
}