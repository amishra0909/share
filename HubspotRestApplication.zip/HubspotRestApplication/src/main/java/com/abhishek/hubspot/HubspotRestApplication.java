package com.abhishek.hubspot;

import com.abhishek.hubspot.service.CacheService;
import com.abhishek.hubspot.service.DatasetService;
import com.abhishek.hubspot.service.ResultService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class HubspotRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HubspotRestApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Bean
	CommandLineRunner start(
			DatasetService datasetService,
			ResultService resultServicem,
			CacheService cacheService) {

		return args -> {
			datasetService.saveDataset(cacheService);
			resultServicem.sendResult(cacheService);
		};
	}
}
