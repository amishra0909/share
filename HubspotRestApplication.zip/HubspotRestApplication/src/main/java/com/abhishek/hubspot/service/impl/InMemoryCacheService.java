package com.abhishek.hubspot.service.impl;

import com.abhishek.hubspot.entity.Event;
import com.abhishek.hubspot.entity.SortedEventSet;
import com.abhishek.hubspot.repository.EventRepository;
import com.abhishek.hubspot.repository.InMemoryEventRepository;
import com.abhishek.hubspot.representation.EventRepresentation;
import com.abhishek.hubspot.service.CacheService;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.Map;

@Service
public class InMemoryCacheService implements CacheService {

    private final EventRepository eventRepository = new InMemoryEventRepository();

    @Override
    public Event save(EventRepresentation eventRepresentation) {

        final var event = Event.builder()
                .timestamp(eventRepresentation.getTimestamp())
                .url(eventRepresentation.getUrl())
                .build();
        eventRepository.add(eventRepresentation.getVisitorId(), event);

        return event;
    }

    @Override
    public Iterator<Map.Entry<String, SortedEventSet>> visitorEvents() {
        return eventRepository.iterator();
    }
}
