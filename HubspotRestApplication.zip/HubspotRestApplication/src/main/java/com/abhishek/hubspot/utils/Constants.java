package com.abhishek.hubspot.utils;

public class Constants {

    public static final String BASE_URL = "https://candidate.hubteam.com/candidateTest/v3/problem";
    public static final String DATASET_PATH = "/dataset";
    public static final String RESULT_PATH = "/result";
    public static final String USER_KEY_QUERY = "userKey=c1f157b56b1ab354bc933b01d454";
}
