package com.abhishek.hubspot.service.impl;

import com.abhishek.hubspot.entity.Event;
import com.abhishek.hubspot.representation.ResultRepresentation;
import com.abhishek.hubspot.entity.Session;
import com.abhishek.hubspot.entity.SortedEventSet;
import com.abhishek.hubspot.service.CacheService;
import com.abhishek.hubspot.service.ResultService;
import com.abhishek.hubspot.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.*;

@Slf4j
@Service
public class SessionResultService implements ResultService {

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public void sendResult(CacheService cacheService) {

        final var getResulttUrl = UriComponentsBuilder.fromUriString(Constants.BASE_URL)
                .path(Constants.RESULT_PATH)
                .query(Constants.USER_KEY_QUERY)
                .build()
                .toUriString();

        final var request = createSession(cacheService);

        final var respEntity = restTemplate.exchange(
                getResulttUrl,
                HttpMethod.POST,
                new HttpEntity<>(request),
                Object.class);

        if (!respEntity.getStatusCode().is2xxSuccessful()) {
            log.error("REST called failed with status : " + respEntity.getStatusCode());
        }
    }

    private ResultRepresentation createSession(CacheService cacheService) {

        Map<String, List<Session>> sessionsByUser = new HashMap<>();

        for (Iterator<Map.Entry<String, SortedEventSet>> it = cacheService.visitorEvents(); it.hasNext(); ) {
            Map.Entry<String, SortedEventSet> eventSetEntry = it.next();

            List<Session> sessions = sessionsByUser.getOrDefault(eventSetEntry.getKey(), new ArrayList<>());

            long lastTime = 0;
            List<String> urls = null;
            long startTime = 0;
            for (Iterator<Event> iter = eventSetEntry.getValue().iterator(); iter.hasNext(); ) {
                Event event = iter.next();

                if (lastTime == 0) { // fist event
                    urls = new ArrayList<>();
                    startTime = event.getTimestamp();
                } else {
                    if (event.getTimestamp() > (lastTime + 600000L)) { // greater than 10 mins
                       long duration = lastTime - startTime;
                       Session session = Session.builder()
                               .duration(duration)
                               .pages(urls)
                               .startTime(startTime)
                               .build();

                       sessions.add(session);

                       // start a new event from current event
                       startTime = event.getTimestamp();
                       urls = new ArrayList<>();
                    }
                }
                lastTime = event.getTimestamp();
                urls.add(event.getUrl());

            }
            long duration = lastTime - startTime;
            Session session = Session.builder()
                    .duration(duration)
                    .pages(urls)
                    .startTime(startTime)
                    .build();

            sessions.add(session);

            sessionsByUser.put(eventSetEntry.getKey(), sessions);

        }

        return ResultRepresentation.builder()
                .sessionsByUser(sessionsByUser)
                .build();

    }
}
