package com.abhishek.hubspot.service;

public interface DatasetService {

    void saveDataset(CacheService cacheService);
}
