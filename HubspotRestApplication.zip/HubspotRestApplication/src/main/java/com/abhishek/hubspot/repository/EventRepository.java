package com.abhishek.hubspot.repository;

import com.abhishek.hubspot.entity.Event;
import com.abhishek.hubspot.entity.SortedEventSet;

import java.util.Iterator;
import java.util.Map;

/**
 * Interface to add events received.
 */
public interface EventRepository {

    void add(String visitorId, Event event);

    Iterator<Map.Entry<String, SortedEventSet>> iterator();
}
