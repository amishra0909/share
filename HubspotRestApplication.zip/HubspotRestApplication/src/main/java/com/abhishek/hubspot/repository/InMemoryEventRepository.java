package com.abhishek.hubspot.repository;

import com.abhishek.hubspot.entity.Event;
import com.abhishek.hubspot.entity.SortedEventSet;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Class to store events in memory.
 * The use of this repository will be to retrieve events by visitorId to calculate session
 * data for each visitor, so the in-memory structure we use is a map of visitorId to sorted
 * set of events.
 */
public class InMemoryEventRepository implements EventRepository {

    private Map<String, SortedEventSet> store;

    public InMemoryEventRepository() {
        this.store = new HashMap<>();
    }

    @Override
    public void add(String visitorId, Event event) {

        if (visitorId == null || visitorId.isBlank()) {
            throw new RuntimeException("Attempted to store event for invalid visitor id.");
        }

        if (event == null) {
            throw new RuntimeException("Attempted to store invalid event.");
        }

        final var sortedEventSet = store.getOrDefault(visitorId, new SortedEventSet());
        sortedEventSet.insert(event);
        store.put(visitorId, sortedEventSet);
    }

    @Override
    public Iterator<Map.Entry<String, SortedEventSet>> iterator() {
        return store.entrySet().iterator();
    }
}
