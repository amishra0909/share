package com.abhishek.hubspot.service;

public interface ResultService {

    void sendResult(CacheService cacheService);
}
