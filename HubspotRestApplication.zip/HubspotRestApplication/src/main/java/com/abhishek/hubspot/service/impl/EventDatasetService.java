package com.abhishek.hubspot.service.impl;

import com.abhishek.hubspot.representation.EventsRepresentation;
import com.abhishek.hubspot.service.CacheService;
import com.abhishek.hubspot.service.DatasetService;
import com.abhishek.hubspot.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
public class EventDatasetService implements DatasetService {

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public void saveDataset(CacheService cacheService) {

        final var getDatasetUrl = UriComponentsBuilder.fromUriString(Constants.BASE_URL)
                .path(Constants.DATASET_PATH)
                .query(Constants.USER_KEY_QUERY)
                .build()
                .toUriString();

        final var respEntity = restTemplate.exchange(
                getDatasetUrl,
                HttpMethod.GET,
                null,
                EventsRepresentation.class);

        if (!respEntity.getStatusCode().is2xxSuccessful()) {
            log.error("REST called failed with status : " + respEntity.getStatusCode());

        }

        final var events = respEntity.getBody();

        for (var event : events.getEvents()) {
            cacheService.save(event);
        }
    }
}
