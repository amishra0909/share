package com.abhishek.hubspot.service;

import com.abhishek.hubspot.entity.Event;
import com.abhishek.hubspot.entity.SortedEventSet;
import com.abhishek.hubspot.representation.EventRepresentation;

import java.util.Iterator;
import java.util.Map;

public interface CacheService {

    Event save(EventRepresentation eventRepresentation);

    Iterator<Map.Entry<String, SortedEventSet>> visitorEvents();
}
