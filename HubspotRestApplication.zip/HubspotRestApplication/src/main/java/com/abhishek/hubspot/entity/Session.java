package com.abhishek.hubspot.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Session {

    @NonNull
    private Long duration;

    private List<String> pages;

    private Long startTime;
}
