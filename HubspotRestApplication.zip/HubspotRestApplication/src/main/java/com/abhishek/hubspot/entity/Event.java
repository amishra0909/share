package com.abhishek.hubspot.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class to represent an event by a user id.
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Event {

    private String url;

    private Long timestamp;
}
