package com.abhishek.hubspot.entity;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

/**
 * Class to represent a sorted set of events.
 * Also, see {@link Event}
 */
public class SortedEventSet {

    private TreeSet<Event> sortedSet;

    /**
     * Constructor.
     */
    public SortedEventSet() {
        this.sortedSet = new TreeSet<>(new Comparator<Event>() {
            @Override
            public int compare(Event o1, Event o2) {
                return Long.compare(o1.getTimestamp(), o2.getTimestamp());
            }
        });
    }

    /**
     * Add an event to the sorted set.
     * @param event Event to be added.
     */
    public void insert(Event event) {
        if (event != null) {
            this.sortedSet.add(event);
        }
    }

    /**
     * Iterator to retrieve sorted events set.
     *
     * @return Iterator to retrieve sorted events set.
     */
    public Iterator<Event> iterator() {
        return sortedSet.iterator();
    }
}
