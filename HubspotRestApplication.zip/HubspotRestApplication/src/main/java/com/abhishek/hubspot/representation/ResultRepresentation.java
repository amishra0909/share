package com.abhishek.hubspot.representation;

import com.abhishek.hubspot.entity.Session;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import java.util.Map;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResultRepresentation {

    @NonNull
    private Map<String, List<Session>> sessionsByUser;

}
